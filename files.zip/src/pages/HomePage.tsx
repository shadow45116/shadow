import React, { useState } from "react";
import HeroSection from "../sections/HeroSection";
import SupportSection from "../sections/SupportSection";
import PodcastSection from "../sections/PodcastSection";
import CasesSection from "../sections/CasesSection";
import FilesSection from "../sections/FilesSection";
import CommunitySection from "../sections/CommunitySection";
import NewsletterSection from "../sections/NewsletterSection";
import Footer from "../sections/Footer";

const HomePage: React.FC = () => {
  // For demonstration, this state could drive reactivity for search, etc.
  const [search, setSearch] = useState("");
  return (
    <div className="dark-bg">
      <HeroSection />
      <SupportSection />
      <PodcastSection />
      <CasesSection search={search} setSearch={setSearch} />
      <FilesSection />
      <CommunitySection />
      <NewsletterSection />
      <Footer />
    </div>
  );
};

export default HomePage;