import React, { useState } from "react";

// Demo static case data (replace with dynamic fetching or CMS in real use)
const cases = [
  {
    id: 1,
    title: "The Disappearance of Jane Doe",
    summary: "A promising student vanished from her campus one night in 2018.",
    link: "#",
  },
  {
    id: 2,
    title: "Vanished Without a Trace: The Miller Case",
    summary: "A small-town mystery with chilling clues and no closure.",
    link: "#",
  },
  // Add more cases as needed
];

const CasesSection: React.FC<{
  search: string;
  setSearch: (val: string) => void;
}> = ({ search, setSearch }) => {
  const filtered = cases.filter(
    c =>
      c.title.toLowerCase().includes(search.toLowerCase()) ||
      c.summary.toLowerCase().includes(search.toLowerCase())
  );
  return (
    <section className="cases-section">
      <h2>Explore True Crime Cases</h2>
      <input
        className="search-input"
        type="text"
        value={search}
        onChange={e => setSearch(e.target.value)}
        placeholder="Search by name, year, location, etc…"
      />
      <div className="cases-list">
        {filtered.length ? (
          filtered.map(c => (
            <div className="case-card" key={c.id}>
              <h3>{c.title}</h3>
              <p>{c.summary}</p>
              <a href={c.link} className="case-link" target="_blank" rel="noopener noreferrer">
                Read more
              </a>
            </div>
          ))
        ) : (
          <p className="no-cases">No cases found.</p>
        )}
      </div>
    </section>
  );
};

export default CasesSection;