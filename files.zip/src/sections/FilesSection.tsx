import React, { useState } from "react";

// Demo static files array (replace with CMS or dashboard upload in real use)
const files = [
  { name: "Case Summary - Jane Doe.pdf", url: "/downloads/jane-doe.pdf" },
  { name: "Podcast Script - Episode 1.pdf", url: "/downloads/ep1-script.pdf" },
];

const FilesSection: React.FC = () => {
  // For admin upload, use dashboard; here, users can only download.
  return (
    <section className="files-section">
      <h2>Downloadable Files & Documents</h2>
      <ul className="files-list">
        {files.map(f => (
          <li key={f.url}>
            <a href={f.url} download target="_blank" rel="noopener noreferrer">
              {f.name}
            </a>
          </li>
        ))}
      </ul>
      <div className="file-upload-placeholder">
        {/* Only visible for admins in Dashboard */}
        <p>
          <em>Files are managed via the dashboard.</em>
        </p>
      </div>
    </section>
  );
};

export default FilesSection;