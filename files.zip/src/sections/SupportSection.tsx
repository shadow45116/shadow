import React from "react";

const SupportSection: React.FC = () => (
  <section className="support-section">
    <h2>Support Our Mission</h2>
    <p>
      Your support helps us research, document, and spread awareness about true crime disappearances and the people behind them.
    </p>
    <a
      href="https://wise.com/your-donation-link" // <-- replace with your Wise donation link
      target="_blank"
      rel="noopener noreferrer"
      className="button donation-button"
    >
      Donate with Wise
    </a>
  </section>
);

export default SupportSection;