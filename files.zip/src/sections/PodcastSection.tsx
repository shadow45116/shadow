import React from "react";

const PodcastSection: React.FC = () => (
  <section className="podcast-section">
    <h2>Listen to Our Podcast</h2>
    <p>
      Explore our episodes for in-depth coverage and interviews. Listen directly below or subscribe on your favorite platform.
    </p>
    {/* Replace with your actual embedded podcast player links */}
    <div className="podcast-embed-list">
      <iframe
        src="https://open.spotify.com/embed/show/your-podcast-id"
        width="100%"
        height="80"
        frameBorder="0"
        allow="autoplay; clipboard-write; encrypted-media; picture-in-picture"
        title="Spotify Podcast"
      ></iframe>
      {/* Add more players as needed */}
    </div>
  </section>
);

export default PodcastSection;