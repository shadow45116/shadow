import React from "react";

const HeroSection: React.FC = () => (
  <section className="hero-section">
    <div className="hero-content">
      <h1>Shadows of the Missing</h1>
      <p className="tagline">
        Uncovering the untold stories behind true crime disappearances.
      </p>
    </div>
  </section>
);

export default HeroSection;