import React, { useState } from "react";

// Simple password-based protection (for demonstration only!)
const PASSWORD = "shadowadmin2024"; // Change this to your secret password

const ProtectedRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [authed, setAuthed] = useState(false);
  const [input, setInput] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (input === PASSWORD) setAuthed(true);
    else alert("Incorrect password.");
  };

  if (authed) return <>{children}</>;
  return (
    <div className="dashboard-bg protected">
      <form className="dashboard-password-form" onSubmit={handleSubmit}>
        <h2>Admin Dashboard Login</h2>
        <input
          type="password"
          placeholder="Enter password"
          value={input}
          onChange={e => setInput(e.target.value)}
          className="dashboard-password-input"
        />
        <button className="button" type="submit">
          Login
        </button>
      </form>
    </div>
  );
};

export default ProtectedRoute;